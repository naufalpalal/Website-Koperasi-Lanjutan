

<?php $__env->startSection(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\user\simpanan\sukarela\pengajuan.blade.php ENDPATH**/ ?>