

<?php $__env->startSection('content'); ?>
<div class="max-w-lg w-full mx-auto p-6 bg-white rounded-lg shadow-lg mt-8">
    <h3 class="text-2xl font-bold mb-6 text-gray-800 text-center sm:text-left">
        Update Nominal Simpanan Wajib
    </h3>

    
    <div class="mb-4">
      
    </div>

    
    <form action="<?php echo e(route('pengurus.simpanan.wajib_2.updateNominal')); ?>" method="POST" class="space-y-4">
        <?php echo csrf_field(); ?>

        
       <div>
    <label for="nilai" class="font-medium block mb-1">Nominal Simpanan Wajib:</label>
    <div class="flex">
        <span class="inline-flex items-center px-3 rounded-l border border-r-0 bg-gray-100 text-gray-700">
            Rp
        </span>
        <input type="number" name="nilai" id="nilai" min="0" required
               class="border rounded-r px-3 py-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-400 appearance-none"
               placeholder="Masukkan nominal"
               onkeydown="return event.keyCode !== 38 && event.keyCode !== 40"
               onwheel="this.blur()"
               style="appearance: textfield; -moz-appearance: textfield;">
    </div>
</div>

        
        <div>
            <label for="periode_mulai" class="font-medium block mb-1">Berlaku Mulai Bulan:</label>
            <input type="month" name="periode_mulai" id="periode_mulai"
                value="<?php echo e(isset($master->periode_mulai) ? $master->periode_mulai->format('Y-m') : now()->format('Y-m')); ?>"
                class="border rounded px-3 py-2 w-full focus:outline-none focus:ring-2 focus:ring-blue-400">
        </div>

        
        <div class="flex flex-col sm:flex-row justify-end gap-2 mt-4">
            <a href="<?php echo e(route('pengurus.simpanan.wajib_2.index')); ?>"
               class="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500 transition text-center">
               Batal
            </a>
            <button type="submit"
                    class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 transition">
                Update
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('pengurus.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\pengurus\Simpanan\wajib_2\edit.blade.php ENDPATH**/ ?>