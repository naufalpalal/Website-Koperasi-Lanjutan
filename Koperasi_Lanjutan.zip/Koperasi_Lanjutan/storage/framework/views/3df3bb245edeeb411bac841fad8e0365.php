
<?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\auth\confirm-password.blade.php ENDPATH**/ ?>