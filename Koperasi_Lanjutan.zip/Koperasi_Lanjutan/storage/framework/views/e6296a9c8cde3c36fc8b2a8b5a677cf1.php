
<?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\auth\verify-email.blade.php ENDPATH**/ ?>