

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto p-6 bg-white rounded-lg shadow-lg mt-8">
    <h3 class="text-2xl font-bold mb-6 text-gray-800">
        Riwayat Simpanan Wajib - <?php echo e($anggota->nama); ?>

    </h3>

    <div class="overflow-x-auto">
        <table class="min-w-full bg-white border rounded-lg shadow">
            <thead>
                <tr class="bg-gray-100">
                    <th class="px-4 py-2 text-left">Periode</th>
                    <th class="px-4 py-2 text-left">Nominal</th>
                    <th class="px-4 py-2 text-left">Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-2">
                        <?php echo e(\Carbon\Carbon::createFromDate($r->tahun, $r->bulan, 1)->translatedFormat('F Y')); ?>

                    </td>
                    <td class="px-4 py-2">Rp <?php echo e(number_format($r->nilai, 0, ',', '.')); ?></td>
                    <td class="px-4 py-2">
                        <span class="<?php echo e($r->status === 'Dibayar' ? 'text-green-600' : 'text-red-600'); ?>">
                            <?php echo e($r->status ?? '-'); ?>

                        </span>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center py-4">Belum ada riwayat simpanan</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-6">
        <a href="<?php echo e(url()->previous()); ?>" 
           class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition">
            Kembali
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengurus.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\pengurus\Simpanan\wajib_2\riwayat.blade.php ENDPATH**/ ?>