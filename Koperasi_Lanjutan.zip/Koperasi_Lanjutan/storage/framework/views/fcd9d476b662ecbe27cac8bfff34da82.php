<?php $__env->startSection('content'); ?>
<div class="p-6 bg-white rounded shadow">
    <h2 class="text-xl font-bold mb-4">Riwayat Simpanan Sukarela</h2>

    <table class="min-w-full border-collapse">
        <thead>
            <tr class="bg-gray-100">
                <th class="px-4 py-2 border">Bulan</th>
                <th class="px-4 py-2 border">Tahun</th>
                <th class="px-4 py-2 border">Nominal</th>
                <th class="px-4 py-2 border">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="px-4 py-2 border"><?php echo e($item->bulan); ?></td>
                <td class="px-4 py-2 border"><?php echo e($item->tahun); ?></td>
                <td class="px-4 py-2 border">Rp <?php echo e(number_format($item->nilai, 0, ',', '.')); ?></td>
                <td class="px-4 py-2 border"><?php echo e($item->status); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4" class="text-center py-4">Belum ada riwayat simpanan.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\user\simpanan\sukarela\riwayat.blade.php ENDPATH**/ ?>