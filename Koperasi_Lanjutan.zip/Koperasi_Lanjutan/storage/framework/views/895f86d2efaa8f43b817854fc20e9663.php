<?php $__env->startSection('title', 'Transaksi Pinjaman Koperasi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto pt-12 px-10">
        <div class="bg-white rounded-xl shadow p-6">
            <h1 class="text-2xl font-semibold text-gray-700 mb-6">Transaksi Pinjaman Koperasi</h1>

            
            <?php if(session('success')): ?>
                <div class="bg-green-100 text-green-700 px-4 py-2 rounded mb-4">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            
            <div class="overflow-x-auto bg-white rounded-lg shadow">
                <table class="min-w-full text-sm text-left border border-gray-200">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-4 py-2 border">Anggota</th>
                            <th class="px-4 py-2 border">Tanggal Pengajuan</th>
                            <th class="px-4 py-2 border">Jumlah Pinjaman</th>
                            <th class="px-4 py-2 border">Status</th>
                            <th class="px-4 py-2 border">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pinjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjaman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-b hover:bg-gray-50">
                                <td class="px-4 py-2"><?php echo e($pinjaman->member->nama); ?></td>
                                <td class="px-4 py-2"><?php echo e($pinjaman->created_at->format('d-m-Y')); ?></td>
                                <td class="px-4 py-2 font-medium">
                                    Rp <?php echo e(number_format($pinjaman->jumlah, 0, ',', '.')); ?>

                                </td>
                                <td class="px-4 py-2">
                                    <span
                                        class="px-2 py-1 rounded text-xs
                                        <?php echo e($pinjaman->status == 'diterima' ? 'bg-green-100 text-green-700' :
                                           ($pinjaman->status == 'ditolak' ? 'bg-red-100 text-red-700' :
                                           'bg-yellow-100 text-yellow-700')); ?>">
                                        <?php echo e(ucfirst($pinjaman->status)); ?>

                                    </span>
                                </td>
                                <td class="px-4 py-2 flex gap-2">
                                    
                                    <form action="<?php echo e(route('admin.pinjaman.update', $pinjaman->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="diterima">
                                        <button type="submit"
                                            class="bg-green-500 hover:bg-green-600 text-white px-3 py-1 rounded text-sm shadow">
                                            Terima
                                        </button>
                                    </form>

                                    
                                    <form action="<?php echo e(route('admin.pinjaman.update', $pinjaman->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <input type="hidden" name="status" value="ditolak">
                                        <button type="submit"
                                            class="bg-red-500 hover:bg-red-600 text-white px-3 py-1 rounded text-sm shadow">
                                            Tolak
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4 text-gray-500">
                                    Tidak ada data pinjaman.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\pengurus\pinjaman\index.blade.php ENDPATH**/ ?>