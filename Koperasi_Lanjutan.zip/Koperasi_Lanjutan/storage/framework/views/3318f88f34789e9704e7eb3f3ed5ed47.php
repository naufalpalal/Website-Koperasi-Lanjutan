<?php $__env->startSection('title', 'Simpanan Sukarela'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto p-6 bg-white rounded-xl shadow-md">
    <h2 class="text-xl font-semibold mb-4">Daftar Simpanan Sukarela</h2>

    <?php if(session('success')): ?>
        <div class="p-3 mb-4 text-green-700 bg-green-100 rounded-lg">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="w-full border-collapse border border-gray-300">
        <thead class="bg-gray-100">
            <tr>
                <th class="border p-2">Bulan</th>
                <th class="border p-2">Jumlah</th>
                <th class="border p-2">Status</th>
                <th class="border p-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $sukarela; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="border p-2"><?php echo e(\Carbon\Carbon::parse($item->month)->format('F Y')); ?></td>
                    <td class="border p-2">Rp <?php echo e(number_format($item->amount,0,',','.')); ?></td>
                    <td class="border p-2">
                        <span class="px-2 py-1 rounded-lg text-white 
                            <?php echo e($item->status == 'pending' ? 'bg-yellow-500' : ($item->status == 'success' ? 'bg-green-500' : 'bg-red-500')); ?>">
                            <?php echo e(ucfirst($item->status)); ?>

                        </span>
                    </td>
                    <td class="border p-2 text-center">
                        <?php if($item->status != 'pending'): ?>
                        <form action="<?php echo e(route('simpanan.sukarela.update', $item->id)); ?>" method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="number" name="amount" placeholder="Nominal baru" class="p-1 border rounded" required>
                            <input type="text" name="note" placeholder="Catatan" class="p-1 border rounded">
                            <button type="submit" class="px-3 py-1 bg-blue-600 text-white rounded hover:bg-blue-700">
                                Ajukan Perubahan
                            </button>
                        </form>
                        <?php else: ?>
                            <em>Sedang menunggu persetujuan</em>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\user\simpanan\sukarela\index.blade.php ENDPATH**/ ?>