
        

        <!-- Nomor Telepon -->
        



<?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\auth\forgot-password.blade.php ENDPATH**/ ?>