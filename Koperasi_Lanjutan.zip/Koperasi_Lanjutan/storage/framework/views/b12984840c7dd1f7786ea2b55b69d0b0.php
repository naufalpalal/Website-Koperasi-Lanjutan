<?php $__env->startSection('content'); ?>
<div class="container mx-auto bg-blue-100 min-h-screen p-6 flex flex-col items-center">
    <!-- Dashboard Title -->
    <div class="text-gray-800 font-bold mb-8 text-2xl">
        Dashboard User
    </div>

    <!-- Grid Menu -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8 w-full max-w-3xl">
        
        <!-- Simpanan Sukarela -->
        <a href="<?php echo e(route('user.simpanan.sukarela.index')); ?>" 
           class="flex flex-col items-center justify-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg hover:scale-105 transition transform">
            <div class="w-16 h-16 flex items-center justify-center bg-blue-200 text-blue-700 rounded-full mb-3">
                <i class="fas fa-piggy-bank text-2xl"></i>
            </div>
            <span class="text-gray-700 font-semibold">Simpanan Sukarela</span>
        </a>

        <!-- Simpanan Wajib -->
        <a href="#" 
           class="flex flex-col items-center justify-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg hover:scale-105 transition transform">
            <div class="w-16 h-16 flex items-center justify-center bg-green-200 text-green-700 rounded-full mb-3">
                <i class="fas fa-coins text-2xl"></i>
            </div>
            <span class="text-gray-700 font-semibold">Simpanan Wajib</span>
        </a>

        <!-- Bisa tambah menu lain -->
        <a href="#" 
           class="flex flex-col items-center justify-center p-6 bg-white rounded-xl shadow-md hover:shadow-lg hover:scale-105 transition transform">
            <div class="w-16 h-16 flex items-center justify-center bg-yellow-200 text-yellow-700 rounded-full mb-3">
                <i class="fas fa-file-alt text-2xl"></i>
            </div>
            <span class="text-gray-700 font-semibold">Laporan</span>
        </a>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\user\dashboard\index.blade.php ENDPATH**/ ?>