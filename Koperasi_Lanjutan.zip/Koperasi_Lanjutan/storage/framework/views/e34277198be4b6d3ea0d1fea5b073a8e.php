

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto p-6 bg-white rounded-lg shadow-lg mt-8">
    <h3 class="text-2xl font-bold mb-6 text-gray-800">Kelola Simpanan Wajib</h3>

    
    <div class="mb-4 flex items-center justify-between">
        <form id="bulanForm" method="GET" action="" class="flex items-center gap-2">
            <label for="filterBulan" class="font-medium mr-2">Periode</label>
            <select id="filterBulan" name="bulan"
                    class="border rounded px-3 py-2 w-40 focus:outline-none focus:ring-2 focus:ring-blue-400"
                    onchange="this.form.submit()">
                <?php if($bulan->isEmpty()): ?>
                    <option value=""><?php echo e(__('Belum ada data')); ?></option>
                <?php else: ?>
                    <?php $__currentLoopData = $bulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($b); ?>" <?php echo e(request('bulan', now()->format('Y-m')) == $b ? 'selected' : ''); ?>>
                            <?php echo e(\Carbon\Carbon::parse($b.'-01')->translatedFormat('F Y')); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </select>
        </form>

        
        <?php 
        $isLocked=false; ?>
        <?php if(!$isLocked): ?>
        <div class="flex items-center gap-3">
            <a href="<?php echo e(route('pengurus.simpanan.wajib_2.download')); ?>" 
            class="text-green-600 hover:text-green-700 transition" 
            title="Download Excel">
                <!-- Icon download -->
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" class="size-6">
                <path fill-rule="evenodd" d="M19.5 21a3 3 0 0 0 3-3V9a3 3 0 0 0-3-3h-5.379a.75.75 0 0 1-.53-.22L11.47 3.66A2.25 2.25 0 0 0 9.879 3H4.5a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3h15Zm-6.75-10.5a.75.75 0 0 0-1.5 0v4.19l-1.72-1.72a.75.75 0 0 0-1.06 1.06l3 3a.75.75 0 0 0 1.06 0l3-3a.75.75 0 1 0-1.06-1.06l-1.72 1.72V10.5Z" clip-rule="evenodd" />
                </svg>
            </a>

            <button id="masuk" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 transition"
                <?php if(!$master): ?> data-nominal-empty="true" <?php endif; ?>>
                setting/add
            </button>
        </div>
        <?php endif; ?>
    </div>

    
    <?php if(!$isLocked): ?>
    <?php endif; ?>

    
    <form action="<?php echo e(route('pengurus.simpanan.wajib_2.updateStatus')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white border rounded-lg shadow">
                <thead>
                    <tr class="bg-gray-100 text-gray-700 text-left">
                        <th class="px-4 py-2">Nama Anggota</th>
                        <th class="px-4 py-2">Nominal</th>
                        <th class="px-4 py-2">Bulan</th>
                        <th class="px-4 py-2">Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $simpanan = $simpananBulanIni->get($a->id);
                        ?>
                        <tr class="border-t hover:bg-gray-50">
                            <td class="px-4 py-2"><?php echo e($a->nama); ?></td>
                            <td class="px-4 py-2">
                                <?php echo e($simpanan ? 'Rp '.number_format($simpanan->nilai, 0, ',', '.') : '-'); ?>

                            </td>
                            <td class="px-4 py-2">
                                <?php echo e($simpanan ? \Carbon\Carbon::createFromDate($simpanan->tahun, $simpanan->bulan, 1)->translatedFormat('F Y') : '-'); ?>

                            </td>
                            <td class="px-4 py-2">
                                <?php echo e($simpanan ? $simpanan->status : '-'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center py-4">Belum ada data</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="flex items-center justify-between mt-6">
            <a href="<?php echo e(route('pengurus.simpanan.wajib_2.riwayat', $a->id ?? 0)); ?>"
               class="text-blue-600 hover:underline">
                Riwayat
            </a>

            <div class="flex gap-3">
            </div>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('pengurus.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\pengurus\Simpanan\wajib_2\dashboard.blade.php ENDPATH**/ ?>