<?php $__env->startSection('content'); ?>
<div class="container">
    <h3>Kelola Laporan</h3>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\xampp\htdocs\Website-Koperasi-Lanjutan\Koperasi_Lanjutan\resources\views\pengurus\laporan\index.blade.php ENDPATH**/ ?>