 <div class="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
            <div class="bg-white rounded-xl shadow flex flex-col items-center p-3 hover:bg-blue-50 cursor-pointer">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 8v4l3 3"/><circle cx="12" cy="12" r="10"/></svg>
                <span class="text-xs font-semibold">Simpan Pinjam</span>
            </div>
            <div class="bg-white rounded-xl shadow flex flex-col items-center p-3 hover:bg-blue-50 cursor-pointer">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-7 w-7 mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path d="M12 8v4l3 3"/><circle cx="12" cy="12" r="10"/></svg>
                <span class="text-xs font-semibold"></span>
        </div>
